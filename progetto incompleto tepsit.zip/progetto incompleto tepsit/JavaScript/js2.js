var i=0;
int A[];
function salvaNumeri() {
	
 var numeri = document.getElementById("numeri").value;
 localStorage.setItem("numeri",numeri);
 mostraNumeri();
 i++;}

function mostraNumeri(){
  
  if(i==0){
    var numeri = localStorage.getItem("numeri");
    document.getElementById("datiSalvati").innerHTML= numeri +" ";
	A[i]=numeri;
    }
  
  if(i==1){
    var numeri = localStorage.getItem("numeri");
    document.getElementById("datiSalvati1").innerHTML= numeri +" ";
	A[i]=numeri;
    }
  
  if(i==2){
    var numeri = localStorage.getItem("numeri");
    document.getElementById("datiSalvati2").innerHTML= numeri +" ";
	A[i]=numeri;
    }
  
  if(i==3){
    var numeri = localStorage.getItem("numeri");
    document.getElementById("datiSalvati3").innerHTML= numeri +" ";
	A[i]=numeri;
    }
  
  if(i==4){
    var numeri = localStorage.getItem("numeri");
    document.getElementById("datiSalvati4").innerHTML= numeri +" ";
	A[i]=numeri;
    }
  
  if(i>=4){
    document.getElementById("button").disabled = true;
  }
}


/* function sposta () {
 alert("counting Sort");
} 


function countingSort()
 {  
     alert("counting Sort");
    //Cacolo degli elementi max e min
    int max=A[0];
    int min=A[0];
    int q=1;
    for( q=1; q<A.length; q++){
       if(A[q]>max) max=A[q];
       else if(A[q]<min) min=A[q];
    }
    //Costruzione dell'array C
    int[] C=new int[max-min+1];           //crea l'array C
    for(q=0; q<C.length; q++) C[q]=0;    //inizializza a zero gli elementi di C
    for(q=0; q<A.length; q++)
       C[A[q]-min]++;                    //aumenta il numero di volte che si � incontrato il valore
    //Ordinamento in base al contenuto dell'array delle frequenze C
    int k=0;                             //indice per l'array A
    for(q=0; q<C.length; q++){
       while(C[q]>0){                     //scrive C[i] volte il valore (i+min) nell'array A
          A[k]=q+min;
          k++;
          C[q]--;
       }
    }
            document.getElementById("datiSalvati").innerHTML= A[0]+" ";
		    document.getElementById("datiSalvati1").innerHTML= A[1]+" ";
	        document.getElementById("datiSalvati2").innerHTML= A[2]+" ";
		    document.getElementById("datiSalvati3").innerHTML= A[3]+" ";
			document.getElementById("datiSalvati4").innerHTML= A[4]+" ";             
 }
//non 'ho ancora implementato
 function mergeSort(int [] array, int min, int max) {

        if((max-min)<20) { 
            insertionSort(array,min,max);
        } else {
            int medio = (min+max)/2;    // Trovo l' indice per suddividere il vettore
            mergeSort(array,min,medio); // Primo sotto-vettore
            mergeSort(array,medio+1,max); // Secondo sotto-vettore
            merge(array,min,medio,max); // Fondo i due sotto-vettori
			   document.getElementById("datiSalvati").innerHTML= A[0]+" ";
		    document.getElementById("datiSalvati1").innerHTML= A[1]+" ";
	        document.getElementById("datiSalvati2").innerHTML= A[2]+" ";
		    document.getElementById("datiSalvati3").innerHTML= A[3]+" ";
			document.getElementById("datiSalvati4").innerHTML= A[4]+" ";    
        }
    }
    // Questo metodo fonde i due sotto-vettori ordinati, in un unico vettore ordinato
   function merge(int [] array, int min, int med, int max) {
        int [] a = new int[max-min+1];
        int i1 = min;
        int i2 = med+1;
        int i3 = 1;
        for(; ( i1 <= med) && (i2 < max); i3++) {
            if(array[i2]>array[i1])) {
                a[i3] = array[i1]; i1++;
            }
            else {
                a[i3] = array[i2]; i2++;
            }
        }
        for(;i1 <= med; i1++, i3++) a[i3] = array[i1];
        for(;i2 < max; i2++, i3++) a[i3] = array[i2];
        for(i3=1, i1=min; i1 < max; i1++, i3++)
            array[i1] = a[i3];
    }
function insertionSort(int [] array, int min, int max) {}
        for(int i = min+1; i < max; i++) {
           int x = i;
           int j = i-1;
           for(; j >= min; j--) {
               if(array[j]>array[x]) {
                   int k = array[x];
                   array[x] = array[j];
                   array[j] = k;
                   x = j;
               } else break;
           }
    }

function bubbleSort() 
     {
     String first;
     String next;
     int i = 5
     while(i>0) 
       {
       for(int j=0; j < i; j++) 
         {
         first = (String) A[j];
         next = (String) A[j+1];
         if(first.compareTo(next)>0)   /*scambiare il '>' con '<' per ottenere un ordinamento decrescente*/
           exchange(A,j,j+1);
         }
       i--; 
       }
	      document.getElementById("datiSalvati").innerHTML= A[0]+" ";
		    document.getElementById("datiSalvati1").innerHTML= A[1]+" ";
	        document.getElementById("datiSalvati2").innerHTML= A[2]+" ";
		    document.getElementById("datiSalvati3").innerHTML= A[3]+" ";
			document.getElementById("datiSalvati4").innerHTML= A[4]+" ";    
     }
 	
  function exchange(Vector v, int i, int j) 
     {
     Object obk = v.elementAt(i);
     v.setElementAt(v.elementAt(j),i);
     v.setElementAt(obk,j);
     }

	function BucketSort()
{
	int[] c = new int[4]; //Array d'appoggio di dimensione m
	int m = A[0];
	int i, k, j = 0;
	for (i = 1; i < 5; i++)
	{
	      if (A[i] > m)
	          m = A[i];
	}
	for (i = 0; i < m; i++)
	{
	      c[i] = 0;
	}
	for (i = 1; i < A.length+1; i++)
	{
	      c[A[i - 1]]++;
	}
	for (i = 0; i < c.length; i++) 
        {
	      for (k = 0; k < c[i]; k++) 
              {
   	          A[j++] = i;
              }
	}
	   document.getElementById("datiSalvati").innerHTML= A[0]+" ";
		    document.getElementById("datiSalvati1").innerHTML= A[1]+" ";
	        document.getElementById("datiSalvati2").innerHTML= A[2]+" ";
		    document.getElementById("datiSalvati3").innerHTML= A[3]+" ";
			document.getElementById("datiSalvati4").innerHTML= A[4]+" ";    
}

//non lho ancora fatto bene
function QuickSort( int [] v , int in , int fin ){
		if( fin<=in )return;
			int pos=partiziona( v,in,fin );
                        /*
                         * Ricorsione...(Quindi algoritmo non in-place , in quanto deve
                         * allocare memoria fino alla risoluzione del problema)
                         */
			QuickSort( v,in,pos-1 );  //Sotto porzione sinistra
			QuickSort( v,pos+1,fin ); //Sotto porzione destra
			   document.getElementById("datiSalvati").innerHTML= A[0]+" ";
		    document.getElementById("datiSalvati1").innerHTML= A[1]+" ";
	        document.getElementById("datiSalvati2").innerHTML= A[2]+" ";
		    document.getElementById("datiSalvati3").innerHTML= A[3]+" ";
			document.getElementById("datiSalvati4").innerHTML= A[4]+" ";    
	}

function partiziona( int[]v , int in , int fin ){
      // L'elemento pivot � il primo (posizione 0)
		int i=in+1,j=fin;
		while( i<=j ){
			while( (i<=fin) && (v[i]<=v[fin]) ) i++;
				while( v[j]>v[in] ) j--;
				if( i<=j ){
                                        // Scambia
					int t=v[i];
					v[i]=v[j];
					v[j]=t;
				}
		}
                // Scambia
		int tt=v[in];
		v[in]=v[i-1];
		v[i-1]=tt;

		return i-1;
	}
